/* ==========================================================
   Carreira 4.0 — JavaScript do site
   ========================================================== */
(function () {
  'use strict';

  var reduzirMovimento = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var temRato = window.matchMedia && window.matchMedia('(hover: hover)').matches;

  function $(s, d) { return (d || document).querySelector(s); }
  function $$(s, d) { return Array.prototype.slice.call((d || document).querySelectorAll(s)); }

  /* ---------- Menu mobile ---------- */
  var botaoMenu = $('#botaoMenu');
  var menu = $('#menu');

  function fecharMenu() {
    if (!menu) return;
    menu.classList.remove('aberto');
    if (botaoMenu) botaoMenu.setAttribute('aria-expanded', 'false');
  }

  if (botaoMenu && menu) {
    botaoMenu.addEventListener('click', function (e) {
      e.stopPropagation();
      var aberto = menu.classList.toggle('aberto');
      botaoMenu.setAttribute('aria-expanded', aberto ? 'true' : 'false');
    });

    menu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') fecharMenu();
    });

    // Fechar ao clicar fora do menu
    document.addEventListener('click', function (e) {
      if (!menu.classList.contains('aberto')) return;
      if (menu.contains(e.target)) return;
      if (botaoMenu.contains(e.target)) return;
      fecharMenu();
    });

    // Fechar com Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') fecharMenu();
    });

    // Fechar ao redimensionar para desktop
    window.addEventListener('resize', function () {
      if (window.innerWidth > 1040) fecharMenu();
    });
  }

  /* ---------- Scroll: progresso, cabeçalho, topo, parallax ---------- */
  var cabecalho = $('.cabecalho-site');
  var barraProgresso = $('#progresso');
  var botaoTopo = $('#botaoTopo');
  var fotoInterna = $('.destaque-foto-interna');
  var aEspera = false;

  function aoRolar() {
    var posicao = window.pageYOffset || document.documentElement.scrollTop || 0;
    var maximo = document.documentElement.scrollHeight - window.innerHeight;
    if (barraProgresso) barraProgresso.style.transform = 'scaleX(' + (maximo > 0 ? Math.min(1, posicao / maximo) : 0) + ')';
    if (cabecalho) cabecalho.classList.toggle('rolado', posicao > 8);
    if (botaoTopo) botaoTopo.classList.toggle('mostrar', posicao > 700);
    if (fotoInterna && !reduzirMovimento && posicao < 1000) {
      fotoInterna.style.transform = 'translate3d(0,' + Math.min(posicao * 0.05, 30).toFixed(1) + 'px,0)';
    }
    aEspera = false;
  }
  window.addEventListener('scroll', function () {
    if (!aEspera) { aEspera = true; window.requestAnimationFrame(aoRolar); }
  }, { passive: true });
  aoRolar();

  if (botaoTopo) {
    botaoTopo.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduzirMovimento ? 'auto' : 'smooth' });
    });
  }

  /* ---------- Menu ativo conforme secção visível ---------- */
  var ligacoes = $$('.menu-principal a[href^="#"]');
  if ('IntersectionObserver' in window && ligacoes.length) {
    var mapa = {};
    ligacoes.forEach(function (a) { mapa[a.getAttribute('href').slice(1)] = a; });
    var obs = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting) return;
        ligacoes.forEach(function (a) { a.classList.remove('ativo'); });
        var a = mapa[e.target.id];
        if (a) a.classList.add('ativo');
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    Object.keys(mapa).forEach(function (id) {
      var s = document.getElementById(id);
      if (s) obs.observe(s);
    });
  }

  /* ---------- Aparecer ao scroll ---------- */
    /* ---------- Aparecer ao scroll ---------- */
  $$('[data-escalonar]').forEach(function (pai) {
    Array.prototype.forEach.call(pai.children, function (filho, i) {
      if (!filho.hasAttribute('data-aparecer')) filho.setAttribute('data-aparecer', 'cima');
      filho.style.setProperty('--indice', i);
      // Se tiver data-animar manual, mantém e usa a ordem para o stagger
      if (filho.hasAttribute('data-animar')) {
        filho.style.setProperty('--ordem', i);
      }
    });
  });

  function mostrar(el) {
    if (el.classList.contains('visivel')) return;
    el.classList.add('visivel');
    var espera = 1000 + (parseInt(el.style.getPropertyValue('--indice'), 10) || 0) * 90;
    window.setTimeout(function () { el.removeAttribute('data-aparecer'); }, espera);
  }
  function crescer(el) { el.classList.add('crescer'); }

  var aparecer = $$('[data-aparecer]');
  var crescerEls = $$('[data-crescer]');

  if (reduzirMovimento || !('IntersectionObserver' in window)) {
    aparecer.forEach(function (el) { el.classList.add('visivel'); el.removeAttribute('data-aparecer'); });
    crescerEls.forEach(crescer);
  } else {
    var obs2 = new IntersectionObserver(function (entradas, o) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting) return;
        if (e.target.hasAttribute('data-crescer')) crescer(e.target);
        if (e.target.hasAttribute('data-aparecer')) mostrar(e.target);
        o.unobserve(e.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    aparecer.concat(crescerEls).forEach(function (el) { obs2.observe(el); });
    window.setTimeout(function () {
      aparecer.forEach(function (el) { if (el.hasAttribute('data-aparecer')) mostrar(el); });
      crescerEls.forEach(crescer);
    }, 5000);
  }

  /* ---------- Contadores animados do painel de destaque ---------- */
  var contadores = $$('[data-contador]');
  function animarContador(el) {
    var alvo = parseInt(el.getAttribute('data-contador'), 10) || 0;
    var sufixo = el.getAttribute('data-sufixo') || '';
    if (reduzirMovimento) { el.textContent = alvo + sufixo; return; }
    var duracao = 1400;
    var inicio = performance.now();
    function passo(agora) {
      var t = Math.min(1, (agora - inicio) / duracao);
      var suavizado = 1 - Math.pow(1 - t, 3);
      el.textContent = Math.round(alvo * suavizado) + sufixo;
      if (t < 1) requestAnimationFrame(passo);
    }
    requestAnimationFrame(passo);
  }
  if (contadores.length) {
    if ('IntersectionObserver' in window) {
      var obs3 = new IntersectionObserver(function (entradas, o) {
        entradas.forEach(function (e) {
          if (!e.isIntersecting) return;
          animarContador(e.target);
          o.unobserve(e.target);
        });
      }, { threshold: 0.5 });
      contadores.forEach(function (c) { obs3.observe(c); });
    } else {
      contadores.forEach(animarContador);
    }
  }

  /* ---------- Ondas nos botões ---------- */
  document.addEventListener('click', function (e) {
    var botao = e.target.closest ? e.target.closest('.botao') : null;
    if (!botao || reduzirMovimento || botao.disabled) return;
    var r = botao.getBoundingClientRect();
    var t = Math.max(r.width, r.height);
    var onda = document.createElement('span');
    onda.className = 'onda';
    onda.style.width = onda.style.height = t + 'px';
    onda.style.left = (e.clientX - r.left - t / 2) + 'px';
    onda.style.top = (e.clientY - r.top - t / 2) + 'px';
    botao.appendChild(onda);
    window.setTimeout(function () { if (onda.parentNode) onda.parentNode.removeChild(onda); }, 650);
  });

})();