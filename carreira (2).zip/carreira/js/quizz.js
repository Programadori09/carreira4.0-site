/* ==========================================================
   Carreira 4.0 — motor do Quizz
   - Perguntas de escolha múltipla
   - Pontuação (10 pontos por resposta certa)
   - Guarda nome + cidade + pontuação no localStorage
   - Ranking ordenado (pontuação desc, data asc)
   - Habilita o 1.º lugar ao prémio mensal
   Para mudar as perguntas: edita a constante PERGUNTAS.
   ========================================================== */

(function () {
  'use strict';

  var PERGUNTAS = [
    {
      q: 'O que significa "competência" no mundo do trabalho?',
      opcoes: [
        'Apenas o diploma que tens na parede',
        'O conjunto de conhecimentos, habilidades e atitudes que te permitem fazer bem uma tarefa',
        'O número de anos que trabalhaste',
        'A empresa onde trabalhas'
      ],
      certa: 1
    },
    {
      q: 'Qual destas é uma "soft skill" (competência comportamental)?',
      opcoes: [
        'Programar em Python',
        'Falar inglês fluente',
        'Trabalhar em equipa',
        'Usar o Excel'
      ],
      certa: 2
    },
    {
      q: 'O que é um currículo (CV)?',
      opcoes: [
        'Um documento que resume a tua formação, experiência e competências',
        'Um certificado de nascimento',
        'Uma carta de recomendação',
        'Um contrato de trabalho'
      ],
      certa: 0
    },
    {
      q: 'Antes de uma entrevista de emprego, o mais importante é:',
      opcoes: [
        'Chegar atrasado para parecer descontraído',
        'Pesquisar sobre a empresa e preparar respostas sobre ti',
        'Levar muitos amigos contigo',
        'Falar só de salário'
      ],
      certa: 1
    },
    {
      q: 'O que é "trabalho remoto"?',
      opcoes: [
        'Trabalho feito fora do escritório, muitas vezes a partir de casa, usando internet',
        'Trabalho em fábricas',
        'Trabalho só aos fins de semana',
        'Trabalho voluntário'
      ],
      certa: 0
    },
    {
      q: 'Qual destas atitudes ajuda a crescer na carreira?',
      opcoes: [
        'Evitar aprender coisas novas',
        'Culpar sempre os outros',
        'Pedir feedback e aceitar críticas construtivas',
        'Chegar sempre tarde'
      ],
      certa: 2
    },
    {
      q: 'O que é um "estágio"?',
      opcoes: [
        'Um castigo no trabalho',
        'Uma experiência profissional temporária para aprender e ganhar prática',
        'Um tipo de salário',
        'Uma reunião de equipa'
      ],
      certa: 1
    },
    {
      q: 'Para te candidatares a uma vaga, normalmente precisas de:',
      opcoes: [
        'Apenas dizer "quero o trabalho"',
        'CV atualizado, carta de apresentação e, por vezes, portfólio',
        'Só o bilhete de identidade',
        'Nada, basta aparecer'
      ],
      certa: 1
    },
    {
      q: 'O que significa "networking"?',
      opcoes: [
        'Trabalhar com computadores em rede',
        'Criar e manter contactos profissionais que podem abrir portas',
        'Navegar nas redes sociais o dia todo',
        'Fazer publicidade paga'
      ],
      certa: 1
    },
    {
      q: 'Qual destas é uma vantagem de continuar a aprender depois de começar a trabalhar?',
      opcoes: [
        'Ficas sempre no mesmo cargo',
        'Perdes tempo',
        'Podes adaptar-te a novas tecnologias e funções, aumentando o teu valor no mercado',
        'Não serve para nada'
      ],
      certa: 2
    }
  ];

  var PONTOS_POR_ACERTO = 10;
  var CHAVE_RANKING = 'carreira40_ranking_v1';
  var CHAVE_JOGADOR = 'carreira40_jogador_v1';

  var ecraInicio    = document.getElementById('quizzEcraInicio');
  var ecraPerguntas = document.getElementById('quizzEcraPerguntas');
  var ecraResultado = document.getElementById('quizzEcraResultado');
  var ecraGuardado  = document.getElementById('quizzEcraGuardado');

  if (!ecraInicio || !ecraPerguntas) return; // segurança

  var botaoComecar   = document.getElementById('quizzComecar');
  var botaoSeguinte  = document.getElementById('quizzSeguinte');
  var botaoRepetir   = document.getElementById('quizzRepetir');
  var botaoJogarNovamente = document.getElementById('quizzJogarNovamente');

  var elContador   = document.getElementById('quizzContador');
  var elBarra      = document.getElementById('quizzBarra');
  var elPergunta   = document.getElementById('quizzPergunta');
  var elOpcoes     = document.getElementById('quizzOpcoes');
  var elPontos     = document.getElementById('quizzPontos');

  var elMedalha    = document.getElementById('quizzMedalha');
  var elTituloFinal= document.getElementById('quizzTituloFinal');
  var elMensagem   = document.getElementById('quizzMensagemFinal');
  var elPontosFim  = document.getElementById('quizzPontosFinal');
  var elAcertosFim = document.getElementById('quizzAcertosFinal');

  var formNome     = document.getElementById('quizzFormularioNome');
  var inputNome    = document.getElementById('quizzNome');
  var inputCidade  = document.getElementById('quizzCidade');

  var corpoRanking = document.getElementById('quizzRankingCorpo');

  var indice = 0;
  var pontos = 0;
  var acertos = 0;
  var bloqueado = false;
  var resultadoAtual = null;

  var letras = ['A', 'B', 'C', 'D', 'E'];

  /* ---------- Ranking ---------- */
  function lerRanking() {
    try {
      var bruto = localStorage.getItem(CHAVE_RANKING);
      if (!bruto) return [];
      var lista = JSON.parse(bruto);
      return Array.isArray(lista) ? lista : [];
    } catch (e) { return []; }
  }

  function guardarRanking(lista) {
    try { localStorage.setItem(CHAVE_RANKING, JSON.stringify(lista)); } catch (e) {}
  }

  function adicionarAoRanking(entrada) {
    var lista = lerRanking();
    lista.push(entrada);
    lista.sort(function (a, b) {
      if (b.pontos !== a.pontos) return b.pontos - a.pontos;
      return a.data - b.data;
    });
    lista = lista.slice(0, 50); // guarda apenas os melhores 50
    guardarRanking(lista);
    return lista;
  }

  function renderizarRanking() {
    if (!corpoRanking) return;
    var lista = lerRanking();
    if (!lista.length) {
      corpoRanking.innerHTML = '<p class="vazio">Ainda não há pontuações guardadas. Sê o primeiro!</p>';
      return;
    }
    var html = '<table><thead><tr><th class="posicao">#</th><th>Nome</th><th>Cidade</th><th class="pontos">Pontos</th></tr></thead><tbody>';
    lista.forEach(function (item, i) {
      html += '<tr' + (i === 0 ? ' class="destaque"' : '') + '>' +
        '<td class="posicao">' + (i + 1) + '</td>' +
        '<td>' + escapar(item.nome) + '</td>' +
        '<td>' + escapar(item.cidade || '—') + '</td>' +
        '<td class="pontos">' + item.pontos + '</td>' +
      '</tr>';
    });
    html += '</tbody></table>';
    corpoRanking.innerHTML = html;
  }

  function escapar(texto) {
    return String(texto).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------- Ecrãs ---------- */
  function mostrarEcra(qual) {
    [ecraInicio, ecraPerguntas, ecraResultado, ecraGuardado].forEach(function (e) {
      if (e) e.hidden = true;
    });
    if (qual) qual.hidden = false;
  }

  /* ---------- Quizz ---------- */
  function comecar() {
    indice = 0;
    pontos = 0;
    acertos = 0;
    resultadoAtual = null;
    mostrarEcra(ecraPerguntas);
    renderizarPergunta();
    elPontos.textContent = '0';
  }

  function renderizarPergunta() {
    var p = PERGUNTAS[indice];
    bloqueado = false;
    elContador.textContent = 'Pergunta ' + (indice + 1) + ' de ' + PERGUNTAS.length;
    elBarra.style.width = ((indice) / PERGUNTAS.length * 100) + '%';
    elPergunta.textContent = p.q;
    elOpcoes.innerHTML = '';
    botaoSeguinte.disabled = true;

    p.opcoes.forEach(function (texto, i) {
      var botao = document.createElement('button');
      botao.type = 'button';
      botao.className = 'quizz-opcao';
      botao.innerHTML = '<span class="letra">' + letras[i] + '</span><span>' + escapar(texto) + '</span>';
      botao.addEventListener('click', function () { responder(i, botao); });
      elOpcoes.appendChild(botao);
    });
  }

  function responder(i, botaoClicado) {
    if (bloqueado) return;
    bloqueado = true;
    var p = PERGUNTAS[indice];
    var certo = i === p.certa;

    if (certo) {
      pontos += PONTOS_POR_ACERTO;
      acertos += 1;
      botaoClicado.classList.add('correta');
    } else {
      botaoClicado.classList.add('errada');
      // mostra a correta também
      var botoes = elOpcoes.querySelectorAll('.quizz-opcao');
      if (botoes[p.certa]) botoes[p.certa].classList.add('correta');
    }

    Array.prototype.forEach.call(elOpcoes.children, function (b) { b.disabled = true; });
    elPontos.textContent = pontos;
    botaoSeguinte.disabled = false;
    botaoSeguinte.textContent = (indice === PERGUNTAS.length - 1) ? 'Ver resultado' : 'Seguinte';
  }

  function avancar() {
    if (indice < PERGUNTAS.length - 1) {
      indice += 1;
      renderizarPergunta();
    } else {
      terminar();
    }
  }

  function terminar() {
    elBarra.style.width = '100%';
    var maximo = PERGUNTAS.length * PONTOS_POR_ACERTO;
    elPontosFim.textContent = pontos;
    elAcertosFim.textContent = acertos + ' respostas certas em ' + PERGUNTAS.length + '.';

    var titulo, mensagem, medalha;
    var proporcao = pontos / maximo;
    if (proporcao === 1)      { medalha = '🏆'; titulo = 'Perfeito!';        mensagem = 'Acertaste tudo. És um expert em carreira!'; }
    else if (proporcao >= .8) { medalha = '🥇'; titulo = 'Excelente!';       mensagem = 'Mostraste grande conhecimento sobre carreira.'; }
    else if (proporcao >= .6) { medalha = '🥈'; titulo = 'Muito bem!';       mensagem = 'Estás no bom caminho. Continua a aprender.'; }
    else if (proporcao >= .4) { medalha = '🥉'; titulo = 'Bom esforço!';     mensagem = 'Já sabes algumas coisas. Revê as que falhaste.'; }
    else                      { medalha = '💡'; titulo = 'Boa tentativa!';   mensagem = 'Aprende mais e tenta outra vez. Vais melhorar!'; }

    elMedalha.textContent = medalha;
    elTituloFinal.textContent = titulo;
    elMensagem.textContent = mensagem;

    resultadoAtual = { pontos: pontos, acertos: acertos, data: Date.now() };

    mostrarEcra(ecraResultado);
    if (inputNome) inputNome.focus();
  }

  function guardarPontuacao(evento) {
    evento.preventDefault();
    if (!resultadoAtual) return;
    var nome = (inputNome.value || '').trim();
    if (nome.length < 2) {
      inputNome.focus();
      inputNome.style.borderColor = '#E53E3E';
      return;
    }
    inputNome.style.borderColor = '';

    var entrada = {
      nome: nome,
      cidade: (inputCidade.value || '').trim(),
      pontos: resultadoAtual.pontos,
      acertos: resultadoAtual.acertos,
      data: resultadoAtual.data
    };
    adicionarAoRanking(entrada);
    try { localStorage.setItem(CHAVE_JOGADOR, JSON.stringify(entrada)); } catch (e) {}

    renderizarRanking();
    mostrarEcra(ecraGuardado);
  }

  /* ---------- Eventos ---------- */
  if (botaoComecar) botaoComecar.addEventListener('click', comecar);
  if (botaoSeguinte) botaoSeguinte.addEventListener('click', avancar);
  if (botaoRepetir) botaoRepetir.addEventListener('click', comecar);
  if (botaoJogarNovamente) botaoJogarNovamente.addEventListener('click', comecar);
  if (formNome) formNome.addEventListener('submit', guardarPontuacao);

  /* ---------- Iniciar ---------- */
  renderizarRanking();
  mostrarEcra(ecraInicio);
})();