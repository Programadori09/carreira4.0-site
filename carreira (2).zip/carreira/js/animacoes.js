/* ==========================================================
   Carreira 4.0 — Animações, loading e transições entre páginas
   Este ficheiro deve ser ligado em TODAS as páginas,
   depois do principal.js (ou em vez dele para as animações).
   ========================================================== */
(function () {
  'use strict';

  var reduzirMovimento = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Configuração ---------- */
  var TEMPO_MINIMO_LOADING = 900; // ms — com o novo loading leve, 900ms chega

  /* ---------- Estado ---------- */
  var instanteLoading = (window.performance && performance.timing && performance.timing.navigationStart)
    ? performance.timing.navigationStart
    : Date.now();

  /* ---------- Anti-flash ---------- */
  function ativarBloqueio() {
    document.documentElement.classList.add('carregando-ativo');
  }
  function desativarBloqueio() {
    document.documentElement.classList.remove('carregando-ativo');
  }

  /* ---------- Ecrã de loading ---------- */
  function criarLoading() {
    var div = document.getElementById('carregando');

    // Fallback: se a página não tiver o overlay no HTML, cria agora
    if (!div) {
      div = document.createElement('div');
      div.id = 'carregando';
      div.setAttribute('aria-hidden', 'true');
      div.innerHTML =
        '<div class="carregando-caixa">' +
          '<img class="carregando-logo" src="imagens/logotipo.png" alt="">' +
          '<div class="carregando-arco"></div>' +
          '<div class="carregando-texto">A carregar' +
            '<span class="carregando-pontos"><span></span><span></span><span></span></span>' +
          '</div>' +
        '</div>';
      document.body.appendChild(div);
    }
  }

  function esconderLoading() {
    var el = document.getElementById('carregando');
    if (!el) { desativarBloqueio(); return; }

    var decorrido = Date.now() - instanteLoading;
    var espera = Math.max(0, TEMPO_MINIMO_LOADING - decorrido);

    window.setTimeout(function () {
      var el2 = document.getElementById('carregando');
      if (!el2) { desativarBloqueio(); return; }
      el2.classList.add('esconder');
      desativarBloqueio();
      window.setTimeout(function () {
        if (el2 && el2.parentNode) el2.parentNode.removeChild(el2);
      }, 600);
    }, espera);
  }

  /* ---------- Barra de progresso de leitura ---------- */
  function criarProgresso() {
    if (document.getElementById('progresso')) return;
    var barra = document.createElement('div');
    barra.id = 'progresso';
    barra.setAttribute('aria-hidden', 'true');
    document.body.appendChild(barra);
  }

  function atualizarProgresso() {
    var barra = document.getElementById('progresso');
    if (!barra) return;
    var posicao = window.pageYOffset || document.documentElement.scrollTop || 0;
    var maximo = document.documentElement.scrollHeight - window.innerHeight;
    var pct = maximo > 0 ? Math.min(1, posicao / maximo) : 0;
    barra.style.transform = 'scaleX(' + pct + ')';
  }

  /* ---------- Reveal ao scroll ---------- */
  function prepararAnimacoes() {
    // Parceiros: aparecem individualmente, uns da esquerda outros da direita
    var parceiros = document.querySelectorAll('.parceiro-cartao');
    if (parceiros.length && 'IntersectionObserver' in window && !reduzirMovimento) {
      var obsP = new IntersectionObserver(function (entradas, o) {
        entradas.forEach(function (e) {
          if (!e.isIntersecting) return;
          e.target.classList.add('visivel');
          o.unobserve(e.target);
        });
      }, { threshold: 0.2, rootMargin: '0px 0px -8% 0px' });
      parceiros.forEach(function (el) { obsP.observe(el); });

      window.setTimeout(function () {
        parceiros.forEach(function (el) { el.classList.add('visivel'); });
      }, 4000);
    } else {
      parceiros.forEach(function (el) { el.classList.add('visivel'); });
    }

    // Reveal genérico com data-animar
    var elementos = document.querySelectorAll('[data-animar]');
    if (!elementos.length) return;

    if (reduzirMovimento || !('IntersectionObserver' in window)) {
      elementos.forEach(function (el) { el.classList.add('visivel'); });
      return;
    }

    var obs = new IntersectionObserver(function (entradas, o) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('visivel');
        o.unobserve(e.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

    elementos.forEach(function (el) { obs.observe(el); });

    window.setTimeout(function () {
      elementos.forEach(function (el) { el.classList.add('visivel'); });
    }, 4000);
  }

  /* ---------- Aplicar [data-animar] automaticamente ---------- */
  function aplicarAutomatico() {
    var alvos = document.querySelectorAll(
      '.cartao, .jogo-cartao, .jogo-bloco, .curso-detalhe, .contacto-cartao, ' +
      '.equipa-cartao, .publico-cartao, .passo, .kg-passo-info, .kg-perfil, ' +
      '.kg-certificado, .chamada-final, .pagina-hero-interno > *'
    );
    alvos.forEach(function (el, i) {
      if (el.hasAttribute('data-animar')) return;
      var tipo = 'cima';
      if (el.classList.contains('jogo-bloco-kandengue') || el.classList.contains('publico-cartao')) tipo = 'esquerda';
      if (el.classList.contains('jogo-bloco-excel') || el.classList.contains('contacto-cartao')) tipo = 'direita';
      if (el.classList.contains('chamada-final') || el.classList.contains('kg-certificado')) tipo = 'zoom';
      el.setAttribute('data-animar', tipo);
      el.style.setProperty('--ordem', Math.min(i, 8));
    });
  }

  /* ---------- Transição ao clicar em links internos ---------- */
  function ligarTransicoes() {
    document.addEventListener('click', function (e) {
      var link = e.target.closest ? e.target.closest('a') : null;
      if (!link) return;

      var href = link.getAttribute('href');
      if (!href) return;

      if (href.indexOf('#') === 0) return;
      if (href.indexOf('mailto:') === 0) return;
      if (href.indexOf('tel:') === 0) return;
      if (link.target === '_blank') return;
      if (link.hasAttribute('download')) return;
      if (e.ctrlKey || e.metaKey || e.shiftKey) return;

      try {
        var url = new URL(link.href, window.location.href);
        if (url.hostname !== window.location.hostname) return;
      } catch (err) { return; }

      if (reduzirMovimento) return;

      e.preventDefault();

      criarLoading();
      document.body.classList.add('a-sair');

      window.setTimeout(function () {
        window.location.href = href;
      }, 400);
    });
  }

  /* ---------- Entrada da página ---------- */
  function animarEntrada() {
    if (reduzirMovimento) return;
    document.body.classList.add('a-entrar');
    window.setTimeout(function () {
      document.body.classList.remove('a-entrar');
    }, 600);
  }

  /* ---------- Scroll otimizado ---------- */
  var aEspera = false;
  function aoRolar() {
    atualizarProgresso();
    aEspera = false;
  }
  window.addEventListener('scroll', function () {
    if (!aEspera) {
      aEspera = true;
      window.requestAnimationFrame(aoRolar);
    }
  }, { passive: true });

  /* ---------- Gestão do histórico (bfcache) ---------- */
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) {
      document.body.classList.remove('a-sair');
      desativarBloqueio();
      var el = document.getElementById('carregando');
      if (el && el.parentNode) el.parentNode.removeChild(el);
    }
  });

  /* ---------- Inicialização ---------- */
  function iniciar() {
    ativarBloqueio();
    criarLoading();
    criarProgresso();

    if (document.readyState === 'complete') {
      esconderLoading();
    } else {
      window.addEventListener('load', esconderLoading);
    }

    aplicarAutomatico();
    prepararAnimacoes();
    ligarTransicoes();
    animarEntrada();
    atualizarProgresso();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }

})();