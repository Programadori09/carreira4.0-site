/* ==========================================================
   Carreira 4.0 — Formulário de contacto → WhatsApp
   Número de destino: +244 925 490 166
   Ao submeter, abre o WhatsApp com a mensagem já escrita.
   ========================================================== */
(function () {
  'use strict';

  var NUMERO_WHATSAPP = '244925490166';

  var form = document.getElementById('contactoForm');
  if (!form) return;

  // Pré-preencher o curso se vier via ?curso=Excel no URL
  var params = new URLSearchParams(window.location.search);
  var cursoURL = params.get('curso');
  var selectCurso = document.getElementById('contactoCurso');
  if (cursoURL && selectCurso) {
    for (var i = 0; i < selectCurso.options.length; i++) {
      if (selectCurso.options[i].text === cursoURL) {
        selectCurso.selectedIndex = i;
        break;
      }
    }
  }

  form.addEventListener('submit', function (evento) {
    evento.preventDefault();

    var nome     = (document.getElementById('contactoNome').value || '').trim();
    var email    = (document.getElementById('contactoEmail').value || '').trim();
    var telefone = (document.getElementById('contactoTelefone').value || '').trim();
    var curso    = (document.getElementById('contactoCurso').value || '').trim();
    var mensagem = (document.getElementById('contactoMensagem').value || '').trim();

    // Validação mínima
    if (nome.length < 2) {
      marcarErro('contactoNome');
      return;
    }
    if (mensagem.length < 5) {
      marcarErro('contactoMensagem');
      return;
    }

    limparErros();

    // Construir mensagem final
    var linhas = [];
    linhas.push('*Contacto Carreira 4.0*');
    linhas.push('');
    linhas.push('*Nome:* ' + nome);
    if (email)    linhas.push('*Email:* ' + email);
    if (telefone) linhas.push('*Telefone:* ' + telefone);
    if (curso)    linhas.push('*Curso de interesse:* ' + curso);
    linhas.push('');
    linhas.push('*Mensagem:*');
    linhas.push(mensagem);

    var texto = encodeURIComponent(linhas.join('\n'));
    var url = 'https://wa.me/' + NUMERO_WHATSAPP + '?text=' + texto;
    window.open(url, '_blank', 'noopener');
  });

  function marcarErro(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.focus();
    el.style.borderColor = '#E53E3E';
    el.style.boxShadow = '0 0 0 3px rgba(229,62,62,.15)';
    el.addEventListener('input', function limpar() {
      el.style.borderColor = '';
      el.style.boxShadow = '';
      el.removeEventListener('input', limpar);
    });
  }

  function limparErros() {
    ['contactoNome', 'contactoMensagem'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) { el.style.borderColor = ''; el.style.boxShadow = ''; }
    });
  }
})();