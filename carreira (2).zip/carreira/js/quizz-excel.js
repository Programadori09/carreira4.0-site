/* ==========================================================
   Carreira 4.0 — Quiz Excel para iniciantes
   - 10 perguntas (baseado no Quiz de Excel Carreira 4.0)
   - 15 segundos por pergunta (tempo esgotado = errada)
   - Pontuação: 1 ponto por resposta certa → máximo 10
   - Guarda nome + cidade + pontuação no localStorage
   - Ranking ordenado (pontuação desc, data asc)
   ========================================================== */
(function () {
  'use strict';

  var PERGUNTAS = [
    {
      q: 'Qual é a principal finalidade do Microsoft Excel?',
      opcoes: [
        'Editar vídeos profissionais',
        'Criar e editar folhas de cálculo',
        'Criar sistemas operativos',
        'Desenvolver apresentações exclusivamente'
      ],
      certa: 1
    },
    {
      q: 'Qual das seguintes fórmulas permite somar os valores das células A1 até A5?',
      opcoes: [
        '=SOMA(A1;A5)',
        '=SOMA(A1:A5)',
        '=ADICIONAR(A1:A5)',
        '=TOTAL(A1:A5)'
      ],
      certa: 1
    },
    {
      q: 'Todas as fórmulas do Excel começam com o sinal de igual (=).',
      opcoes: [
        'Verdadeiro',
        'Falso',
        'Só as avançadas',
        'Só as de soma'
      ],
      certa: 0
    },
    {
      q: 'Uma empresa vendeu 20 unidades a 5.000 Kz cada. Quantidade em A2, preço em B2. Qual fórmula dá o valor total?',
      opcoes: [
        '=A2+B2',
        '=A2*B2',
        '=A2/B2',
        '=A2-B2'
      ],
      certa: 1
    },
    {
      q: 'Quais destas funções podem ser usadas para analisar dados financeiros?',
      opcoes: [
        'SOMA',
        'MÉDIA',
        'MÁXIMO',
        'Todas as opções anteriores'
      ],
      certa: 3
    },
    {
      q: 'Qual é o resultado da fórmula =MÉDIA(10;20;30)?',
      opcoes: ['10', '20', '30', '60'],
      certa: 1
    },
    {
      q: 'Se copiares =A1+B1 de C1 para C2, o Excel ajusta automaticamente as referências relativas para =A2+B2.',
      opcoes: [
        'Verdadeiro',
        'Falso',
        'Só com $',
        'Só se travar a célula'
      ],
      certa: 0
    },
    {
      q: 'Para calcular IVA de 14% apenas se o valor for superior a 100.000 Kz, qual função lógica usas?',
      opcoes: ['SE', 'PROCV', 'SOMA.SE', 'CONT.SE'],
      certa: 0
    },
    {
      q: 'Para procurar o preço de um artigo numa tabela de inventário pelo código de referência, qual função é ideal?',
      opcoes: ['MÉDIA', 'PROCV (ou PROCX)', 'DIREITA', 'MAIOR'],
      certa: 1
    },
    {
      q: 'Usar referências absolutas (com $, ex.: $A$1) é fundamental ao calcular taxas fixas aplicadas a uma coluna inteira.',
      opcoes: [
        'Verdadeiro',
        'Falso',
        'Só em gráficos',
        'Só com macros'
      ],
      certa: 0
    }
  ];

  var TEMPO_POR_PERGUNTA = 15;   // segundos
  var PONTOS_ACERTO = 1;          // 1 ponto por resposta certa → máximo 10
  var CHAVE_RANKING = 'carreira40_ranking_excel_v1';

  var ecraInicio    = document.getElementById('quizzEcraInicio');
  var ecraPerguntas = document.getElementById('quizzEcraPerguntas');
  var ecraResultado = document.getElementById('quizzEcraResultado');
  var ecraGuardado  = document.getElementById('quizzEcraGuardado');
  if (!ecraInicio || !ecraPerguntas) return;

  var botaoComecar        = document.getElementById('quizzComecar');
  var botaoSeguinte       = document.getElementById('quizzSeguinte');
  var botaoRepetir        = document.getElementById('quizzRepetir');
  var botaoJogarNovamente = document.getElementById('quizzJogarNovamente');

  var elContador    = document.getElementById('quizzContador');
  var elBarra       = document.getElementById('quizzBarra');
  var elPergunta    = document.getElementById('quizzPergunta');
  var elOpcoes      = document.getElementById('quizzOpcoes');
  var elPontos      = document.getElementById('quizzPontos');
  var elTempo       = document.getElementById('quizzTempo');
  var elTempoBarra  = document.getElementById('quizzTempoBarra');

  var elMedalha     = document.getElementById('quizzMedalha');
  var elTituloFinal = document.getElementById('quizzTituloFinal');
  var elMensagem    = document.getElementById('quizzMensagemFinal');
  var elPontosFim   = document.getElementById('quizzPontosFinal');
  var elAcertosFim  = document.getElementById('quizzAcertosFinal');

  var formNome      = document.getElementById('quizzFormularioNome');
  var inputNome     = document.getElementById('quizzNome');
  var inputCidade   = document.getElementById('quizzCidade');

  var corpoRanking  = document.getElementById('quizzRankingCorpo');

  var indice = 0, pontos = 0, acertos = 0;
  var bloqueado = false, resultadoAtual = null;
  var tempoRestante = TEMPO_POR_PERGUNTA;
  var intervaloTempo = null;

  var letras = ['A', 'B', 'C', 'D', 'E'];

  /* ---------- Ranking ---------- */
  function lerRanking() {
    try {
      var b = localStorage.getItem(CHAVE_RANKING);
      return b ? (JSON.parse(b) || []) : [];
    } catch (e) { return []; }
  }
  function guardarRanking(lista) {
    try { localStorage.setItem(CHAVE_RANKING, JSON.stringify(lista)); } catch (e) {}
  }
  function adicionarAoRanking(entrada) {
    var lista = lerRanking();
    lista.push(entrada);
    lista.sort(function (a, b) {
      if (b.pontos !== a.pontos) return b.pontos - a.pontos;
      return a.data - b.data;
    });
    lista = lista.slice(0, 50);
    guardarRanking(lista);
  }
  function escapar(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function renderizarRanking() {
    if (!corpoRanking) return;
    var lista = lerRanking();
    if (!lista.length) {
      corpoRanking.innerHTML = '<p class="vazio">Ainda não há pontuações guardadas. Sê o primeiro!</p>';
      return;
    }
    var html = '<table><thead><tr><th class="posicao">#</th><th>Nome</th><th>Cidade</th><th class="pontos">Pontos</th></tr></thead><tbody>';
    lista.forEach(function (it, i) {
      html += '<tr' + (i === 0 ? ' class="destaque"' : '') + '>' +
        '<td class="posicao">' + (i + 1) + '</td>' +
        '<td>' + escapar(it.nome) + '</td>' +
        '<td>' + escapar(it.cidade || '—') + '</td>' +
        '<td class="pontos">' + it.pontos + '</td>' +
      '</tr>';
    });
    html += '</tbody></table>';
    corpoRanking.innerHTML = html;
  }

  /* ---------- Ecrãs ---------- */
  function mostrarEcra(qual) {
    [ecraInicio, ecraPerguntas, ecraResultado, ecraGuardado].forEach(function (e) {
      if (e) e.hidden = true;
    });
    if (qual) qual.hidden = false;
  }

  /* ---------- Tempo ---------- */
  function pararTempo() {
    if (intervaloTempo) { clearInterval(intervaloTempo); intervaloTempo = null; }
  }
  function iniciarTempo() {
    pararTempo();
    tempoRestante = TEMPO_POR_PERGUNTA;
    atualizarTempoUI();
    intervaloTempo = setInterval(function () {
      tempoRestante -= 0.1;
      if (tempoRestante <= 0) {
        tempoRestante = 0;
        atualizarTempoUI();
        pararTempo();
        responder(-1, null); // tempo esgotado → conta como errada
        return;
      }
      atualizarTempoUI();
    }, 100);
  }
  function atualizarTempoUI() {
    var s = Math.ceil(tempoRestante);
    if (elTempo) elTempo.textContent = s;
    if (elTempoBarra) {
      var pct = (tempoRestante / TEMPO_POR_PERGUNTA) * 100;
      elTempoBarra.style.width = pct + '%';
      elTempoBarra.style.background = pct < 30 ? '#E53E3E' : 'var(--degrade)';
    }
  }

  /* ---------- Quiz ---------- */
  function comecar() {
    indice = 0; pontos = 0; acertos = 0;
    resultadoAtual = null;
    mostrarEcra(ecraPerguntas);
    renderizarPergunta();
    if (elPontos) elPontos.textContent = '0';
  }

  function renderizarPergunta() {
    var p = PERGUNTAS[indice];
    bloqueado = false;
    elContador.textContent = 'Pergunta ' + (indice + 1) + ' de ' + PERGUNTAS.length;
    elBarra.style.width = (indice / PERGUNTAS.length * 100) + '%';
    elPergunta.textContent = p.q;
    elOpcoes.innerHTML = '';
    botaoSeguinte.disabled = true;
    botaoSeguinte.textContent = (indice === PERGUNTAS.length - 1) ? 'Ver resultado' : 'Seguinte';

    p.opcoes.forEach(function (texto, i) {
      var botao = document.createElement('button');
      botao.type = 'button';
      botao.className = 'quizz-opcao';
      botao.innerHTML = '<span class="letra">' + letras[i] + '</span><span>' + escapar(texto) + '</span>';
      botao.addEventListener('click', function () { responder(i, botao); });
      elOpcoes.appendChild(botao);
    });

    iniciarTempo();
  }

  function responder(i, botaoClicado) {
    if (bloqueado) return;
    bloqueado = true;
    pararTempo();

    var p = PERGUNTAS[indice];
    var certo = i === p.certa;

    if (certo) {
      pontos += PONTOS_ACERTO;
      acertos += 1;
      if (botaoClicado) botaoClicado.classList.add('correta');
    } else {
      if (botaoClicado) botaoClicado.classList.add('errada');
      var botoes = elOpcoes.querySelectorAll('.quizz-opcao');
      if (botoes[p.certa]) botoes[p.certa].classList.add('correta');
    }

    Array.prototype.forEach.call(elOpcoes.children, function (b) { b.disabled = true; });
    if (elPontos) elPontos.textContent = pontos;
    botaoSeguinte.disabled = false;
  }

  function avancar() {
    if (indice < PERGUNTAS.length - 1) {
      indice += 1;
      renderizarPergunta();
    } else {
      terminar();
    }
  }

  function terminar() {
    pararTempo();
    elBarra.style.width = '100%';
    var maximo = PERGUNTAS.length * PONTOS_ACERTO; // = 10
    elPontosFim.textContent = pontos + ' / ' + maximo;
    elAcertosFim.textContent = acertos + ' respostas certas em ' + PERGUNTAS.length + '.';

    var titulo, mensagem, medalha;
    var proporcao = acertos / PERGUNTAS.length;
    if (proporcao === 1)      { medalha = '🏆'; titulo = 'Perfeito!';     mensagem = 'Acertaste tudo. És um expert em Excel!'; }
    else if (proporcao >= .8) { medalha = '🥇'; titulo = 'Excelente!';    mensagem = 'Dominas bem o Excel. Continua assim.'; }
    else if (proporcao >= .6) { medalha = '🥈'; titulo = 'Muito bem!';    mensagem = 'Estás no bom caminho. Pratica mais um pouco.'; }
    else if (proporcao >= .4) { medalha = '🥉'; titulo = 'Bom esforço!';  mensagem = 'Já sabes algumas coisas. Revê as que falhaste.'; }
    else                      { medalha = '💡'; titulo = 'Boa tentativa!'; mensagem = 'Aprende mais e tenta outra vez. Vais melhorar!'; }

    elMedalha.textContent = medalha;
    elTituloFinal.textContent = titulo;
    elMensagem.textContent = mensagem;

    resultadoAtual = { pontos: pontos, acertos: acertos, data: Date.now() };
    mostrarEcra(ecraResultado);
    if (inputNome) inputNome.focus();
  }

  function guardarPontuacao(ev) {
    ev.preventDefault();
    if (!resultadoAtual) return;
    var nome = (inputNome.value || '').trim();
    if (nome.length < 2) {
      inputNome.focus();
      inputNome.style.borderColor = '#E53E3E';
      return;
    }
    inputNome.style.borderColor = '';

    adicionarAoRanking({
      nome: nome,
      cidade: (inputCidade.value || '').trim(),
      pontos: resultadoAtual.pontos,
      acertos: resultadoAtual.acertos,
      data: resultadoAtual.data
    });

    renderizarRanking();
    mostrarEcra(ecraGuardado);
  }

  /* ---------- Eventos ---------- */
  if (botaoComecar) botaoComecar.addEventListener('click', comecar);
  if (botaoSeguinte) botaoSeguinte.addEventListener('click', avancar);
  if (botaoRepetir) botaoRepetir.addEventListener('click', comecar);
  if (botaoJogarNovamente) botaoJogarNovamente.addEventListener('click', comecar);
  if (formNome) formNome.addEventListener('submit', guardarPontuacao);

  renderizarRanking();
  mostrarEcra(ecraInicio);
})();