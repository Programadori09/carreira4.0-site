/* ==========================================================
   Carreira 4.0 — Carreira Kandengue
   Quiz de orientação vocacional para crianças dos 9 aos 14 anos.
   Baseado no quiz oficial: 10 perguntas, 6 perfis possíveis.
   No fim, emite um Certificado de Mérito.
   ========================================================== */

(function () {
  'use strict';

  /* ---------- PERGUNTAS (10) ---------- */
  var PERGUNTAS = [
    {
      titulo: 'O mistério da escola',
      q: 'Um dia, chegas à escola e descobres que todos os computadores deixaram de funcionar. Ninguém sabe porquê. O que terias mais vontade de fazer?',
      opcoes: [
        { letra: 'A', texto: 'Investigar o problema e descobrir o que provocou a avaria.', pontos: { cien: 2, amb: 1 } },
        { letra: 'B', texto: 'Organizar os colegas para encontrar uma solução em conjunto.', pontos: { gest: 2, saude: 1 } },
        { letra: 'C', texto: 'Pensar numa forma diferente de continuar as atividades sem computadores.', pontos: { cria: 2 } },
        { letra: 'D', texto: 'Procurar compreender como os computadores funcionam e o que os faz falhar.', pontos: { cien: 2, constr: 1 } }
      ]
    },
    {
      titulo: 'O desafio de construir algo novo',
      q: 'A tua turma recebe o desafio de construir uma ponte em miniatura que consiga suportar o peso de vários livros. Qual seria a tua maior motivação?',
      opcoes: [
        { letra: 'A', texto: 'Fazer cálculos e testar qual estrutura suporta mais peso.', pontos: { cien: 2, constr: 2 } },
        { letra: 'B', texto: 'Desenhar uma ponte bonita, original e diferente das outras.', pontos: { cria: 2 } },
        { letra: 'C', texto: 'Coordenar os colegas para que todos contribuam para a construção.', pontos: { gest: 2, saude: 1 } },
        { letra: 'D', texto: 'Experimentar diferentes materiais para descobrir qual funciona melhor.', pontos: { constr: 2, cien: 1 } }
      ]
    },
    {
      titulo: 'Um colega com dificuldades',
      q: 'Um colega teu está triste porque tenta resolver um problema de Matemática, mas não consegue. O que farias espontaneamente?',
      opcoes: [
        { letra: 'A', texto: 'Sentar-me com ele e explicar o problema passo a passo.', pontos: { saude: 2, gest: 1 } },
        { letra: 'B', texto: 'Tentar descobrir exatamente em que parte do raciocínio ele está a falhar.', pontos: { cien: 2, amb: 1 } },
        { letra: 'C', texto: 'Criar um exemplo divertido ou um jogo para facilitar a compreensão.', pontos: { cria: 2, saude: 1 } },
        { letra: 'D', texto: 'Incentivá-lo, ajudá-lo a recuperar a confiança e continuar a tentar.', pontos: { saude: 2 } }
      ]
    },
    {
      titulo: 'A tua cidade ideal',
      q: 'Imagina que tens a oportunidade de participar na criação de uma cidade do futuro. Qual destas tarefas escolherias?',
      opcoes: [
        { letra: 'A', texto: 'Planear estradas, edifícios, pontes e sistemas de transporte.', pontos: { constr: 2, cien: 1 } },
        { letra: 'B', texto: 'Criar regras para tornar a cidade mais organizada, justa e segura.', pontos: { gest: 2, saude: 1 } },
        { letra: 'C', texto: 'Desenvolver tecnologias que tornem a cidade mais inteligente.', pontos: { cien: 2, constr: 1 } },
        { letra: 'D', texto: 'Encontrar formas de proteger a natureza e reduzir a poluição.', pontos: { amb: 2 } }
      ]
    },
    {
      titulo: 'O dinheiro da turma',
      q: 'A tua turma organiza uma feira para angariar dinheiro para uma atividade escolar. Qual destas tarefas gostarias mais de realizar?',
      opcoes: [
        { letra: 'A', texto: 'Controlar o dinheiro recebido, as despesas e o lucro.', pontos: { gest: 2 } },
        { letra: 'B', texto: 'Convencer as pessoas a visitar a feira e comprar os produtos.', pontos: { cria: 2, gest: 1 } },
        { letra: 'C', texto: 'Organizar a equipa, distribuir tarefas e garantir que tudo funciona.', pontos: { gest: 2, saude: 1 } },
        { letra: 'D', texto: 'Criar produtos originais que despertem a curiosidade dos visitantes.', pontos: { cria: 2 } }
      ]
    },
    {
      titulo: 'Uma descoberta surpreendente',
      q: 'Durante uma visita de estudo, descobres uma planta que se fecha quando alguém lhe toca. Qual seria a tua primeira reação?',
      opcoes: [
        { letra: 'A', texto: 'Fazer experiências para descobrir por que razão a planta reage assim.', pontos: { cien: 2, amb: 1 } },
        { letra: 'B', texto: 'Investigar como essa descoberta pode ajudar os seres humanos ou a natureza.', pontos: { amb: 2, saude: 1 } },
        { letra: 'C', texto: 'Registar as observações, comparar os resultados e procurar padrões.', pontos: { cien: 2 } },
        { letra: 'D', texto: 'Imaginar uma tecnologia inspirada nessa planta para resolver um problema.', pontos: { cria: 1, cien: 1, constr: 1 } }
      ]
    },
    {
      titulo: 'O dia em que és o responsável',
      q: 'O professor escolhe-te para liderar um grupo de cinco colegas num projeto importante. Qual seria o teu maior desafio?',
      opcoes: [
        { letra: 'A', texto: 'Distribuir as tarefas e garantir que o grupo cumpre os objetivos.', pontos: { gest: 2 } },
        { letra: 'B', texto: 'Ouvir as opiniões de todos e resolver possíveis desentendimentos.', pontos: { saude: 2, gest: 1 } },
        { letra: 'C', texto: 'Encontrar a melhor estratégia para concluir o projeto com sucesso.', pontos: { gest: 2, cien: 1 } },
        { letra: 'D', texto: 'Apresentar as ideias do grupo de forma clara e convencer os outros da sua importância.', pontos: { cria: 2, gest: 1 } }
      ]
    },
    {
      titulo: 'Um problema na comunidade',
      q: 'Descobres que, no teu bairro, muitas pessoas desperdiçam água potável. Se pudesses desenvolver uma solução, qual escolherias?',
      opcoes: [
        { letra: 'A', texto: 'Criar um dispositivo que detete fugas e reduza o desperdício.', pontos: { constr: 2, cien: 1 } },
        { letra: 'B', texto: 'Organizar uma campanha para ensinar as pessoas a utilizar a água de forma responsável.', pontos: { saude: 2, cria: 1 } },
        { letra: 'C', texto: 'Estudar o problema para calcular quanta água é desperdiçada e identificar as principais causas.', pontos: { cien: 2, amb: 1 } },
        { letra: 'D', texto: 'Projetar um sistema que permita recolher e aproveitar a água da chuva.', pontos: { constr: 2, amb: 1 } }
      ]
    },
    {
      titulo: 'O teu projeto de sonho',
      q: 'A escola dá-te liberdade para desenvolver um projeto durante um mês. Podes escolher qualquer tema. Qual destes projetos te entusiasmaria mais?',
      opcoes: [
        { letra: 'A', texto: 'Criar um jogo digital ou uma aplicação para telemóvel.', pontos: { cien: 2, cria: 1 } },
        { letra: 'B', texto: 'Investigar uma doença e descobrir como os profissionais de saúde ajudam as pessoas.', pontos: { saude: 2, cien: 1 } },
        { letra: 'C', texto: 'Criar uma marca, desenvolver produtos e imaginar como vendê-los.', pontos: { gest: 2, cria: 1 } },
        { letra: 'D', texto: 'Produzir um documentário, escrever uma história ou criar uma campanha de comunicação.', pontos: { cria: 2 } }
      ]
    },
    {
      titulo: 'A escolha sem medo',
      q: 'Imagina que podes passar uma semana a aprender com um profissional. Qual destas experiências escolherias?',
      opcoes: [
        { letra: 'A', texto: 'Acompanhar um engenheiro, arquiteto ou especialista em tecnologia.', pontos: { constr: 2, cien: 1 } },
        { letra: 'B', texto: 'Acompanhar um médico, psicólogo ou professor.', pontos: { saude: 2 } },
        { letra: 'C', texto: 'Acompanhar um gestor, contabilista ou empreendedor.', pontos: { gest: 2 } },
        { letra: 'D', texto: 'Acompanhar um cientista, investigador ou especialista ambiental.', pontos: { amb: 2, cien: 1 } }
      ]
    }
  ];

  /* ---------- PERFIS ---------- */
  var PERFIS = {
    cien:  { chave: 'cien',  nome: 'Científico e Tecnológico',       icone: '🔬', cor: 'cor-ceu',     descricao: 'Gostas de descobrir como as coisas funcionam, investigar problemas, experimentar e encontrar explicações.', areas: 'Ciências e Tecnologias, Informática e Programação, Engenharia e investigação científica.', cursos: ['Informática','Eletricidade','Eletrónica','Mecânica'] },
    saude: { chave: 'saude', nome: 'Saúde e Apoio Humano',           icone: '❤️', cor: 'cor-verde',   descricao: 'Interessa-te compreender as pessoas, explicar, apoiar, cuidar ou encontrar soluções para dificuldades humanas.', areas: 'Ciências da Saúde, Psicologia, Educação, Enfermagem e Serviço Social.', cursos: ['Saúde','Ciências Biológicas','Psicologia','Educação'] },
    gest:  { chave: 'gest',  nome: 'Gestão e Negócios',              icone: '📊', cor: 'cor-roxo',    descricao: 'Gostas de organizar recursos, tomar decisões, planear atividades, controlar dinheiro ou transformar ideias em projetos.', areas: 'Contabilidade e Finanças, Gestão de Empresas, Administração, Empreendedorismo e Marketing.', cursos: ['Contabilidade e Gestão','Gestão de Empresas','Administração','Comércio'] },
    cria:  { chave: 'cria',  nome: 'Criativo e Comunicador',         icone: '🎨', cor: 'cor-azul',    descricao: 'Gostas de imaginar soluções, desenhar, criar histórias, apresentar ideias ou encontrar formas originais de transmitir mensagens.', areas: 'Comunicação, Design, Arquitetura, Marketing, Audiovisual e Multimédia.', cursos: ['Design','Comunicação','Multimédia','Artes'] },
    constr:{ chave: 'constr',nome: 'Construção e Soluções Práticas', icone: '🔧', cor: 'cor-marinho', descricao: 'Sentes-te motivado a construir, montar, testar materiais, projetar estruturas ou resolver problemas concretos.', areas: 'Engenharia Civil, Arquitetura, Mecânica, Eletrotecnia e Construção Civil.', cursos: ['Construção Civil','Mecânica','Eletricidade','Eletrotecnia'] },
    amb:   { chave: 'amb',   nome: 'Ambiental e de Investigação',    icone: '🌱', cor: 'cor-verde',   descricao: 'Tens curiosidade pela natureza, pelos fenómenos naturais, pelas experiências e por soluções para problemas ambientais.', areas: 'Ciências Biológicas, Ambiente, Agronomia, investigação científica e Recursos Naturais.', cursos: ['Ciências Biológicas','Ambiente','Agricultura','Agronomia'] }
  };

  /* ---------- ELEMENTOS ---------- */
  var ecraInicio    = document.getElementById('kgEcraInicio');
  var ecraPerguntas = document.getElementById('kgEcraPerguntas');
  var ecraResultado = document.getElementById('kgEcraResultado');
  if (!ecraInicio || !ecraPerguntas) return;

  var form        = document.getElementById('kgFormulario');
  var inputNome   = document.getElementById('kgNome');
  var inputIdade  = document.getElementById('kgIdade');
  var inputEscola = document.getElementById('kgEscola');

  var elContador  = document.getElementById('kgContador');
  var elBarra     = document.getElementById('kgBarra');
  var elPergunta  = document.getElementById('kgPergunta');
  var elOpcoes    = document.getElementById('kgOpcoes');
  var botaoAnt    = document.getElementById('kgAnterior');
  var botaoSeg    = document.getElementById('kgSeguinte');

  var elResNome   = document.getElementById('kgResultadoNome');
  var alvoResultado = document.getElementById('kgPerfis'); // container onde entra o certificado
  var botaoRepetir  = document.getElementById('kgRepetir');
  var botaoImprimir = document.getElementById('kgImprimir');

  /* ---------- ESTADO ---------- */
  var indice = 0;
  var respostas = [];
  var dados = { nome: '', idade: '', escola: '' };

  /* ---------- ECRÃS ---------- */
  function mostrarEcra(qual) {
    [ecraInicio, ecraPerguntas, ecraResultado].forEach(function (e) {
      if (e) e.hidden = true;
    });
    if (qual) qual.hidden = false;
  }

  /* ---------- INÍCIO ---------- */
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var nome = (inputNome.value || '').trim();
      var idade = parseInt(inputIdade.value, 10);
      if (nome.length < 2) { inputNome.focus(); inputNome.style.borderColor = '#E53E3E'; return; }
      if (!idade || idade < 9 || idade > 14) { inputIdade.focus(); inputIdade.style.borderColor = '#E53E3E'; return; }
      inputNome.style.borderColor = '';
      inputIdade.style.borderColor = '';

      dados.nome = nome;
      dados.idade = idade;
      dados.escola = (inputEscola.value || '').trim();

      indice = 0;
      respostas = [];
      mostrarEcra(ecraPerguntas);
      renderizarPergunta();
    });
  }

  /* ---------- PERGUNTA ---------- */
  function renderizarPergunta() {
    var p = PERGUNTAS[indice];
    elContador.textContent = 'Pergunta ' + (indice + 1) + ' de ' + PERGUNTAS.length;
    elBarra.style.width = (indice / PERGUNTAS.length * 100) + '%';
    elPergunta.textContent = p.q;

    elOpcoes.innerHTML = '';
    p.opcoes.forEach(function (op, i) {
      var botao = document.createElement('button');
      botao.type = 'button';
      botao.className = 'kg-opcao';
      botao.innerHTML =
        '<span class="letra">' + op.letra + '</span>' +
        '<span>' + escapar(op.texto) + '</span>';
      if (respostas[indice] === i) botao.classList.add('selecionada');
      botao.addEventListener('click', function () { selecionar(i); });
      elOpcoes.appendChild(botao);
    });

    botaoAnt.disabled = indice === 0;
    botaoSeg.disabled = respostas[indice] === undefined;

    botaoSeg.innerHTML = '';
    botaoSeg.appendChild(document.createTextNode(
      indice === PERGUNTAS.length - 1 ? 'Ver certificado' : 'Seguinte'
    ));
    var icone = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icone.setAttribute('class', 'icone');
    icone.setAttribute('viewBox', '0 0 24 24');
    icone.setAttribute('aria-hidden', 'true');
    var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M5 12h14M13 6l6 6-6 6');
    icone.appendChild(path);
    botaoSeg.appendChild(icone);
  }

  function selecionar(i) {
    respostas[indice] = i;
    Array.prototype.forEach.call(elOpcoes.children, function (b, k) {
      b.classList.toggle('selecionada', k === i);
    });
    botaoSeg.disabled = false;
  }

  function avancar() {
    if (respostas[indice] === undefined) return;
    if (indice < PERGUNTAS.length - 1) {
      indice += 1;
      renderizarPergunta();
    } else {
      terminar();
    }
  }

  function retroceder() {
    if (indice > 0) {
      indice -= 1;
      renderizarPergunta();
    }
  }

  /* ---------- RESULTADO ---------- */
  function calcularPerfis() {
    var pontos = { cien: 0, saude: 0, gest: 0, cria: 0, constr: 0, amb: 0 };
    respostas.forEach(function (escolha, i) {
      var op = PERGUNTAS[i].opcoes[escolha];
      if (!op || !op.pontos) return;
      Object.keys(op.pontos).forEach(function (k) {
        pontos[k] = (pontos[k] || 0) + op.pontos[k];
      });
    });
    var lista = Object.keys(PERFIS).map(function (k) {
      return { perfil: PERFIS[k], pontos: pontos[k] || 0 };
    });
    lista.sort(function (a, b) { return b.pontos - a.pontos; });
    return lista.filter(function (p) { return p.pontos > 0; });
  }

  function terminar() {
    elBarra.style.width = '100%';
    var top = calcularPerfis();

    var nome = dados.nome || 'Criança';
    var principal = top.length ? top[0].perfil : { nome: 'Explorador', icone: '🎯' };

    // Data em português
    var hoje = new Date();
    var meses = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
    var dataTexto = hoje.getDate() + ' de ' + meses[hoje.getMonth()] + ' de ' + hoje.getFullYear();

    elResNome.textContent = 'Carreira Kandengue · ' + nome;

    // Construir o certificado
    alvoResultado.innerHTML = '';
    var cartao = document.createElement('div');
    cartao.className = 'kg-certificado';
    cartao.innerHTML =
      '<span class="kg-cert-ornamento" aria-hidden="true"></span>' +
      '<div class="kg-cert-coroa" aria-hidden="true">🏅</div>' +
      '<div class="kg-cert-etiqueta">Certificado de Mérito</div>' +
      '<h2 class="kg-cert-titulo">Carreira Kandengue</h2>' +
      '<p class="kg-cert-sub">Concluiu com sucesso o quiz de orientação vocacional da Carreira 4.0.</p>' +
      '<div class="kg-cert-nome">' + escapar(nome) + '</div>' +
      '<div class="kg-cert-linha" aria-hidden="true"></div>' +
      '<p class="kg-cert-texto">Parabéns! Descobriste algo importante sobre ti. ' +
        'O teu talento aponta para a área de <strong>' + escapar(principal.nome) + '</strong>. ' +
        'Continua curioso(a) e curte cada descoberta.</p>' +
      '<div class="kg-cert-perfil">' +
        '<span class="kg-cert-perfil-icone" aria-hidden="true">' + principal.icone + '</span>' +
        '<span>' +
          '<small>Perfil principal</small>' +
          '<b>' + escapar(principal.nome) + '</b>' +
        '</span>' +
      '</div>' +
      '<div class="kg-cert-rodape">' +
        '<div class="kg-cert-data">' +
          'Emitido a' +
          '<b>' + dataTexto + '</b>' +
        '</div>' +
        '<div class="kg-cert-assinatura">' +
          '<div class="kg-cert-assinatura-nome" aria-hidden="true">Marcos Prata</div>' +
          '<div class="kg-cert-assinatura-linha" aria-hidden="true"></div>' +
          '<div class="kg-cert-assinatura-cargo">Coordenação · Carreira 4.0</div>' +
        '</div>' +
      '</div>';
    alvoResultado.appendChild(cartao);

    mostrarEcra(ecraResultado);
    window.setTimeout(function () {
      ecraResultado.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  }

  /* ---------- UTILITÁRIOS ---------- */
  function escapar(t) {
    return String(t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------- BOTÕES ---------- */
  if (botaoAnt) botaoAnt.addEventListener('click', retroceder);
  if (botaoSeg) botaoSeg.addEventListener('click', avancar);

  if (botaoRepetir) {
    botaoRepetir.addEventListener('click', function () {
      indice = 0;
      respostas = [];
      if (form) form.reset();
      dados = { nome: '', idade: '', escola: '' };
      alvoResultado.innerHTML = '';
      mostrarEcra(ecraInicio);
      window.scrollTo({ top: document.getElementById('jogo').offsetTop - 80, behavior: 'smooth' });
    });
  }

  if (botaoImprimir) {
    botaoImprimir.addEventListener('click', function () { window.print(); });
  }

  /* ---------- INICIAR ---------- */
  mostrarEcra(ecraInicio);
})();